document.oncontextmenu = () => {
	alert("Don't right click")
	return false
}
